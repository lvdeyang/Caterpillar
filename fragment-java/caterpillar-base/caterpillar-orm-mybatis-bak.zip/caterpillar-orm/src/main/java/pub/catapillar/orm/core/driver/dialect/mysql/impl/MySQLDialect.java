package pub.catapillar.orm.core.driver.dialect.mysql.impl;

import pub.catapillar.orm.core.driver.dialect.DatabaseDialect;
import pub.catapillar.orm.core.entity.filed.DataType;

/**
 * MySQL方言实现
 * lvdeyang 2017年6月14日
 */
public class MySQLDialect implements DatabaseDialect {

	private DataType dataType;
	
	public DataType getDataType() {
		return dataType;
	}

	public void setDataType(DataType dataType) {
		this.dataType = dataType;
	}
	
	@Override
	public DataType getDialectDataType() {
		return dataType;
	}

	@Override
	public String NOTNULL() {
		return "NOT NULL";
	}

	@Override
	public String UNIQUE() {
		return "UNIQUE";
	}

	@Override
	public String UNSIGNED() {
		return "UNSIGNED";
	}
	
}
