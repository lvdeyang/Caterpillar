package pub.catapillar.orm.core.entity.metadata;

/**
 * entity元数据管理
 * lvdeyang 2017年6月14日
 */
public interface EntityMetadataManager {

}
