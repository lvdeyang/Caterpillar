package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

/**
 * MySQl主键元数据
 * lvdeyang 2014年6月16日
 */
public class MySQLPrimaryKeyMetadataPO {

	//主键列名
	private String COLUMN_NAME;

	public String getCOLUMN_NAME() {
		return COLUMN_NAME;
	}

	public MySQLPrimaryKeyMetadataPO setCOLUMN_NAME(String cOLUMN_NAME) {
		COLUMN_NAME = cOLUMN_NAME;
		return this;
	}
	
}
