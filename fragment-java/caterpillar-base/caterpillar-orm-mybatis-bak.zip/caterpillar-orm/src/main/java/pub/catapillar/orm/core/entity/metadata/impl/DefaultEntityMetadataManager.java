package pub.catapillar.orm.core.entity.metadata.impl;

import pub.catapillar.orm.core.entity.metadata.EntityMetadataManager;

/**
 * entity 元数据解析器默认实现
 * lvdeyang 2017年6月14日
 */
public class DefaultEntityMetadataManager implements EntityMetadataManager {
	
}
