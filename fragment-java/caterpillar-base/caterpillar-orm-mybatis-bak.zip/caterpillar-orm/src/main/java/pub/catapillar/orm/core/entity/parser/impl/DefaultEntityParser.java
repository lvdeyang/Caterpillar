package pub.catapillar.orm.core.entity.parser.impl;

import java.lang.reflect.Field;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import pub.catapillar.orm.core.driver.EntityAutoBuildingDriver;
import pub.catapillar.orm.core.driver.dialect.DatabaseDialect;
import pub.catapillar.orm.core.entity.annotation.Table;
import pub.catapillar.orm.core.entity.annotation.enumeration.FieldType;
import pub.catapillar.orm.core.entity.metadata.EntityMetadataManager;
import pub.catapillar.orm.core.entity.parser.EntityParser;

/**
 * entity解析器默认实现
 * lvdeyang 2017年6月14日
 */
public class DefaultEntityParser implements EntityParser{

	//注入驱动
	@Autowired
	private EntityAutoBuildingDriver entityAutoBuildingDriver;
	
	@Override
	public void parse(Set<Class> entitySet) {
		
		//entity元数据管理器
		EntityMetadataManager entityMetadataManager = entityAutoBuildingDriver.getMetadataManager();
		
		//数据库方言
		DatabaseDialect dialect = entityAutoBuildingDriver.getDialect();
		
		for(Class entity:entitySet){
			
			//解析表名
			String tableName = entity.getName();
			if(entity.isAnnotationPresent(Table.class)){
				Table table = (Table)entity.getAnnotation(Table.class);
				if(table.name() != null){
					tableName = table.name();
				}
			}
			
			//解析字段
			Field[]  fields = entity.getFields();
			for(Field field:fields){
				
				//解析字段名
				
				
				
			}
		}
		
	}

}
