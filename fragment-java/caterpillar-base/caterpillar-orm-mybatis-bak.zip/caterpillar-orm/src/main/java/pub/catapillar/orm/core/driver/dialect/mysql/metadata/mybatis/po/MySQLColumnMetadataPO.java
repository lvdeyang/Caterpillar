package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

/**
 * MySQL列元数据
 * lvdeyang 2017年6月16日
 */
public class MySQLColumnMetadataPO {

	//列名称
	private String COLUMN_NAME;
	
	//列数据类型
	private String COLUMN_TYPE;
	
	//列是否可以为空
	private String IS_NULLABLE;

	public String getCOLUMN_NAME() {
		return COLUMN_NAME;
	}

	public MySQLColumnMetadataPO setCOLUMN_NAME(String cOLUMN_NAME) {
		COLUMN_NAME = cOLUMN_NAME;
		return this;
	}

	public String getCOLUMN_TYPE() {
		return COLUMN_TYPE;
	}

	public MySQLColumnMetadataPO setCOLUMN_TYPE(String cOLUMN_TYPE) {
		COLUMN_TYPE = cOLUMN_TYPE;
		return this;
	}

	public String getIS_NULLABLE() {
		return IS_NULLABLE;
	}

	public MySQLColumnMetadataPO setIS_NULLABLE(String iS_NULLABLE) {
		IS_NULLABLE = iS_NULLABLE;
		return this;
	}
	
}
