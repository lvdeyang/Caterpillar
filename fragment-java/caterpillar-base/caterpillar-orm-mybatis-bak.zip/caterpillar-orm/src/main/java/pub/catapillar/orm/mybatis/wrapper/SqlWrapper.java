package pub.catapillar.orm.mybatis.wrapper;

public class SqlWrapper {

	private String sql;
	
	public SqlWrapper(String sql){
		this.sql = sql;
	}

	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}
	
	
}
