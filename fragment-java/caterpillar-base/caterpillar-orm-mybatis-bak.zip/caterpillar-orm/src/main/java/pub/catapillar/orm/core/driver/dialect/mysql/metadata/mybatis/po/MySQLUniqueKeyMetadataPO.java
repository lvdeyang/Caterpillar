package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

/**
 * MySQL唯一键约束元数据
 * lvdeyang 2017年6月16日
 */
public class MySQLUniqueKeyMetadataPO {

	//唯一键约束名称
	private String CONSTRAINT_NAME;
	
	//唯一键列名称
	private String COLUMN_NAME;

	public String getCONSTRAINT_NAME() {
		return CONSTRAINT_NAME;
	}

	public MySQLUniqueKeyMetadataPO setCONSTRAINT_NAME(String cONSTRAINT_NAME) {
		CONSTRAINT_NAME = cONSTRAINT_NAME;
		return this;
	}

	public String getCOLUMN_NAME() {
		return COLUMN_NAME;
	}

	public MySQLUniqueKeyMetadataPO setCOLUMN_NAME(String cOLUMN_NAME) {
		COLUMN_NAME = cOLUMN_NAME;
		return this;
	}
	
}
