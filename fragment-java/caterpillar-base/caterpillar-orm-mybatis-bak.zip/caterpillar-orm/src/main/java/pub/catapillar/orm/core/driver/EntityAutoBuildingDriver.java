package pub.catapillar.orm.core.driver;

import java.util.Set;
import java.util.function.Function;

import com.sun.tools.doclets.internal.toolkit.taglets.ReturnTaglet;

import pub.catapillar.orm.core.driver.dialect.DatabaseDialect;
import pub.catapillar.orm.core.driver.loader.EntityLoader;
import pub.catapillar.orm.core.entity.annotation.enumeration.FieldType;
import pub.catapillar.orm.core.entity.metadata.EntityMetadataManager;
import pub.catapillar.orm.core.entity.parser.EntityParser;

/**
 * entity自动构建驱动
 * lvdeyang 2017年6月14日
 */
public class EntityAutoBuildingDriver {

	//配置是否自动构建表
	private boolean autoBuild;
	
	//配置构建类型--创建1，修改2，删除3--先写死是6
	private int buildType = 6;
	
	//是否打印sql
	private boolean showSql;
	
	//数据库方言
	private static DatabaseDialect dialect;
	
	//entity加载器
	private EntityLoader entityLoader;
	
	//entity扫描路径
	private Set<String> entityPath;
	
	//entity元数据缓存
	private EntityMetadataManager metadataManager;
	
	//entity解析器
	private EntityParser entityParser;
	
	public boolean isAutoBuild() {
		return autoBuild;
	}

	public EntityAutoBuildingDriver setAutoBuild(boolean autoBuild) {
		this.autoBuild = autoBuild;
		return this;
	}

	public int getBuildType() {
		return buildType;
	}

	public EntityAutoBuildingDriver setBuildType(int buildType) {
		this.buildType = buildType;
		return this;
	}

	public boolean isShowSql() {
		return showSql;
	}

	public EntityAutoBuildingDriver setShowSql(boolean showSql) {
		this.showSql = showSql;
		return this;
	}
	
	public static DatabaseDialect getDialect() {
		return dialect;
	}

	public EntityAutoBuildingDriver setDialect(DatabaseDialect dialect) {
		EntityAutoBuildingDriver.dialect = dialect;
		return this;
	}

	public EntityLoader getEntityLoader() {
		return entityLoader;
	}

	public void setEntityLoader(EntityLoader entityLoader) {
		this.entityLoader = entityLoader;
	}

	public Set<String> getEntityPath() {
		return entityPath;
	}

	public EntityAutoBuildingDriver setEntityPath(Set<String> entityPath) {
		this.entityPath = entityPath;
		return this;
	}

	public EntityMetadataManager getMetadataManager() {
		return metadataManager;
	}

	public EntityAutoBuildingDriver setMetadataManager(EntityMetadataManager metadataManager) {
		this.metadataManager = metadataManager;
		return this;
	}
	
	public EntityParser getEntityParser() {
		return entityParser;
	}

	public EntityAutoBuildingDriver setEntityParser(EntityParser entityParser) {
		this.entityParser = entityParser;
		return this;
	}

	//开始构建
	public void buid(){
		
		try {
			Set<Class> entitySet = this.entityLoader.loadEntity(this.entityPath);
			
			this.entityParser.parse(entitySet);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
