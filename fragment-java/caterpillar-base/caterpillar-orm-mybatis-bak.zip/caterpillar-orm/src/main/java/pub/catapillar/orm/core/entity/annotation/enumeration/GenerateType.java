package pub.catapillar.orm.core.entity.annotation.enumeration;

/**
 * 字段生成器类型
 * lvdeyang 2017年6月14日
 */
public enum GenerateType {

	//自增
	AUTOINCREASE,
	
	//序列
	SEQUENCE,
	
	//表
	TABLE;
	
}




