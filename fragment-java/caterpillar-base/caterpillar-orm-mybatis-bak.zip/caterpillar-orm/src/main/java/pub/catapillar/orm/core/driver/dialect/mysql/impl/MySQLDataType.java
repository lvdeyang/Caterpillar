package pub.catapillar.orm.core.driver.dialect.mysql.impl;

import pub.catapillar.orm.core.entity.filed.DataType;
import pub.catapillar.orm.core.entity.filed.DataTypeMetaData;

/**
 * MySQL 数据类型
 * lvdeyang 2017年6月14日
 */
public class MySQLDataType implements DataType {
	
	/*******************
	 *      文本类型
	 *******************/
	
	//CHAR max 255--字符
	@Override
	public DataTypeMetaData CHAR(){
		return new DataTypeMetaData().setName("CHAR").setDataType(this);
	}
	
	//VARCHAR max 255--字符
	@Override
	public DataTypeMetaData VARCHAR(){
		return new DataTypeMetaData().setName("VARCHAR").setDataType(this);
	}
	
	//TINYTEXT max 255--字符
	@Override
	public DataTypeMetaData TINYTEXT(){
		return new DataTypeMetaData().setName("TINYTEXT").setDataType(this);
	}
	
	//TEXT max  65535--字符
	@Override
	public DataTypeMetaData TEXT(){
		return new DataTypeMetaData().setName("TEXT").setDataType(this);
	}
	
	//BLOB max 65,535--字节
	@Override
	public DataTypeMetaData BLOB(){
		return new DataTypeMetaData().setName("BLOB").setDataType(this);
	}
	
	//MEDIUMTEXT max 16,777,215--字符
	@Override
	public DataTypeMetaData MEDIUMTEXT(){
		return new DataTypeMetaData().setName("MEDIUMTEXT").setDataType(this);
		
	}
	
	//MEDIUMBLOB max 16,777,215--字节
	@Override
	public DataTypeMetaData MEDIUMBLOB(){
		return new DataTypeMetaData().setName("MEDIUMBLOB").setDataType(this);
	}
	
	//LONGTEXT max  4,294,967,295--字符
	@Override
	public DataTypeMetaData LONGTEXT(){
		return new DataTypeMetaData().setName("LONGTEXT").setDataType(this);
	}
	
	//LONGBLOB max  4,294,967,295--字节
	@Override
	public DataTypeMetaData LONGBLOB(){
		return new DataTypeMetaData().setName("LONGBLOB").setDataType(this);
	}
	
	//ENUM 实现DataType， 提供带参数的构造方法，重写toString方法
	@Override
	public DataTypeMetaData ENUM(){
		return new DataTypeMetaData().setName("ENUM").setDataType(this);
	}
	
	/*******************
	 *      数字类型
	 *******************/
	
	//单字节  -128 到 127 常规。0 到 255 无符号*
	@Override
	public DataTypeMetaData TINYINT(){
		return new DataTypeMetaData().setName("TINYINT").setSize(1l).setDataType(this);
	}
	
	//双字节  -32768 到 32767 常规。0 到 65535 无符号*
	@Override
	public DataTypeMetaData SMALLINT(){
		return new DataTypeMetaData().setName("SMALLINT").setSize(2l).setDataType(this);
	}
	
	//三字节 -8388608 到 8388607 普通。0 to 16777215 无符号*
	@Override
	public DataTypeMetaData MEDIUMINT(){
		return new DataTypeMetaData().setName("MEDIUMINT").setSize(3l).setDataType(this);
	}
	
	//四字节 -2147483648 到 2147483647 常规。0 到 4294967295 无符号*
	@Override
	public DataTypeMetaData INT(){
		return new DataTypeMetaData().setName("INT").setSize(4l).setDataType(this);
	}
	
	//八字节 -9223372036854775808 到 9223372036854775807 常规。0 到 18446744073709551615 无符号*
	@Override
	public DataTypeMetaData BIGINT(){
		return new DataTypeMetaData().setName("BIGINT").setSize(8l).setDataType(this);
	}
	
	//四字节
	@Override
	public DataTypeMetaData FLOAT(){
		return new DataTypeMetaData().setName("FLOAT").setSize(4l).setDataType(this);
	}
	
	//八字节
	@Override
	public DataTypeMetaData DOUBLE(){
		return new DataTypeMetaData().setName("DOUBLE").setSize(8l).setDataType(this);
	}
	
	//八字节
	@Override
	public DataTypeMetaData DECIMAL(){
		return new DataTypeMetaData().setName("DECIMAL").setSize(8l).setDataType(this);
	}
	
	/*******************
	 *      数字类型
	 *******************/
	
	//日期格式
	public DataTypeMetaData DATE(){
		return new DataTypeMetaData().setName("DATE").setFormat("YYYY-MM-DD").setDataType(this);
	}
	
	//日期和时间组合
	public DataTypeMetaData DATETIME(){
		return new DataTypeMetaData().setName("DATETIME").setFormat("YYYY-MM-DD HH:MM:SS").setDataType(this);
	}
	
	//时间戳
	public DataTypeMetaData TIMESTAMP(){
		return new DataTypeMetaData().setName("TIMESTAMP").setFormat("YYYY-MM-DD HH:MM:SS").setDataType(this);
	}
	
	//时间
	public DataTypeMetaData TIME(){
		return new DataTypeMetaData().setName("TIME").setFormat("HH:MM:SS").setDataType(this);
	}
	
	//年
	public DataTypeMetaData YEAR(){
		return new DataTypeMetaData().setName("YEAR").setFormat("YYYY").setDataType(this);
	}
	
}
