package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

public class MySQLViewMetadataPO {

}
