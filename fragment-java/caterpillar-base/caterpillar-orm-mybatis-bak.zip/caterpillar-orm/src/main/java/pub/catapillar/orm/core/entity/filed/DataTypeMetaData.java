package pub.catapillar.orm.core.entity.filed;

import org.apache.commons.lang3.StringUtils;

import pub.caterpillar.commons.util.wrapper.StringBufferWrapper;

/**
 * 数据类型元数据
 * lvdeyang 2017年6月14日
 */
public class DataTypeMetaData {

	//数据类型实现--用作类型检验
	private DataType dataType; 
	
	//数据类型名称
	private String name;
	
	//数据类型长度
	private Long size;
	
	//小数长度
	private Integer decimals;
	
	//枚举类型
	private DataType[] types;
	
	//数据类型的格式
	private String format;
	
	public DataType getDataType() {
		return dataType;
	}

	public DataTypeMetaData setDataType(DataType dataType) {
		this.dataType = dataType;
		return this;
	}

	public String getName() {
		return name;
	}

	public DataTypeMetaData setName(String name) {
		this.name = name;
		return this;
	}

	public Long getSize() {
		return size;
	}

	public DataTypeMetaData setSize(Long size) {
		this.size = size;
		return this;
	}

	public Integer getDecimals() {
		return decimals;
	}

	public DataTypeMetaData setDecimals(Integer decimals) {
		this.decimals = decimals;
		return this;
	}

	public DataType[] getTypes() {
		return types;
	}

	public DataTypeMetaData setTypes(DataType[] types) {
		this.types = types;
		return this;
	}

	public String getFormat() {
		return format;
	}

	public DataTypeMetaData setFormat(String format) {
		this.format = format;
		return this;
	}

	@Override
	public String toString(){
		
		StringBufferWrapper sbw = new StringBufferWrapper().append(this.name);
		
		if(this.size != null){
			if(this.decimals != null){
				return sbw.append("(").append(this.size).append(", ").append(this.decimals).append(")").toString();
			}else{
				return sbw.append("(").append(this.size).append(")").toString();
			}
		}
		
		if(this.types!=null && this.types.length>0){
			return sbw.append("(").append(StringUtils.join(this.types, ",")).append(")").toString();
		}
		
		return name;
		
	}
	
}
