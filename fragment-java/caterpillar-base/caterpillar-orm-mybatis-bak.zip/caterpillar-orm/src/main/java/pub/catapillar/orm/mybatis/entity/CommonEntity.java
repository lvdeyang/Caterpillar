package pub.catapillar.orm.mybatis.entity;

import pub.catapillar.orm.core.entity.annotation.Column;
import pub.catapillar.orm.core.entity.annotation.enumeration.FieldType;

/**
 * mybatis基础po
 * lvdeyang 2017年6月16日
 */
public class CommonEntity {

	@Column(name="ID", type=FieldType.BIGINT, autoIncreace=true, nullable=false)
	private Long id;
	
	@Column(name="UUID", type=FieldType.VARCHAR, length=64l)
	private String uuid;

	public Long getId() {
		return id;
	}

	public CommonEntity setId(Long id) {
		this.id = id;
		return this;
	}

	public String getUuid() {
		return uuid;
	}

	public CommonEntity setUuid(String uuid) {
		this.uuid = uuid;
		return this;
	}
	
}
