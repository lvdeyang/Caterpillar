package pub.catapillar.orm.core.driver.loader.impl;

import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import pub.catapillar.orm.core.driver.loader.EntityLoader;
import pub.catapillar.orm.core.entity.annotation.Entity;
import pub.caterpillar.commons.util.path.PathUtil;
import pub.caterpillar.commons.util.wrapper.StringBufferWrapper;

/**
 * entity 加载器默认实现
 * lvdeyang 2017年6月15日
 */
public class DefaultEntityLoader implements EntityLoader {

	//spring资源加载器
	private ResourcePatternResolver resolver = null;
	
	//类路径
	private String classPath = null;
	
	//WEB-INF路径
	private String webInfPath = null;
	
	//日志
	private Logger logger = null;
	
	public DefaultEntityLoader(){
		super();
		this.resolver = new PathMatchingResourcePatternResolver();
		this.classPath = PathUtil.getClassPath();
		this.webInfPath = PathUtil.getWebinfPath();
		this.logger = Logger.getLogger(DefaultEntityLoader.class.getName());
	}
	
	public ResourcePatternResolver getResolver() {
		return resolver;
	}

	public void setResolver(ResourcePatternResolver resolver) {
		this.resolver = resolver;
	}

	@Override
	public Set<Class> loadEntity(Collection<String> pathArr) throws Exception {
		
		Set<Class> entitySet = new HashSet<Class>();
		
		for(String path:pathArr){
			Resource[] resources = resolver.getResources(path);
			
			for(Resource resource:resources){
				
				//entity绝对路径
				String uri = resource.getURI().toString();
				
				//entity全包名
				String fullName = "";
				
				if(uri.indexOf(this.classPath) >= 0){
					//类路径下的entity
					uri = uri.split(this.classPath)[1].replace(".class", "");
					uri = uri.substring(1, uri.length());
					fullName = uri.replace("/", ".");
				}else{
					//jar包中的entity
					uri = uri.split(this.webInfPath)[1].replace(".class", "");
					String[] packages = uri.split("/");
					StringBufferWrapper sbw = new StringBufferWrapper();
					for(int i=3; i<packages.length; i++){
						sbw.append(packages[i]).append(".");
					}
					fullName = sbw.toString().substring(0, sbw.toString().length()-1);
				}
				
				logger.debug(new StringBufferWrapper().append("***loading entity class:").append(fullName).toString());
				
				Class target = Class.forName(fullName);
				if(target.isAnnotationPresent(Entity.class)){
					entitySet.add(target);
				}
			}
		}
		
		return entitySet;
	}

}
