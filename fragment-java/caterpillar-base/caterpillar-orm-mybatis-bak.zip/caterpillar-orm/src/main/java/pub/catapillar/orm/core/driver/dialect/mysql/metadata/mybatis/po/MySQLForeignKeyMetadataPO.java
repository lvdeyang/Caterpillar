package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

/**
 * MySQL外键信息
 * lvdeyang 2017年6月16日
 */
public class MySQLForeignKeyMetadataPO {

	//约束名称（外键名称）
	private String CONSTRAINT_NAME;
	
	//约束列名
	private String COLUMN_NAME;
	
	//关联的表名
	private String REFERENCED_TABLE_NAME;
	
	//关联表的列名
	private String REFERENCED_COLUMN_NAME;

	public String getCONSTRAINT_NAME() {
		return CONSTRAINT_NAME;
	}

	public void setCONSTRAINT_NAME(String cONSTRAINT_NAME) {
		CONSTRAINT_NAME = cONSTRAINT_NAME;
	}

	public String getCOLUMN_NAME() {
		return COLUMN_NAME;
	}

	public void setCOLUMN_NAME(String cOLUMN_NAME) {
		COLUMN_NAME = cOLUMN_NAME;
	}

	public String getREFERENCED_TABLE_NAME() {
		return REFERENCED_TABLE_NAME;
	}

	public void setREFERENCED_TABLE_NAME(String rEFERENCED_TABLE_NAME) {
		REFERENCED_TABLE_NAME = rEFERENCED_TABLE_NAME;
	}

	public String getREFERENCED_COLUMN_NAME() {
		return REFERENCED_COLUMN_NAME;
	}

	public void setREFERENCED_COLUMN_NAME(String rEFERENCED_COLUMN_NAME) {
		REFERENCED_COLUMN_NAME = rEFERENCED_COLUMN_NAME;
	}
	
}
