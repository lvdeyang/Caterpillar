package pub.catapillar.orm.core.driver.enumeration;

/**
 * 自动建表类型
 * lvdeyang 2017年6月14日
 */
public enum EntityBuildType {

	//创建
	CREATE(1), 
	
	//更新
	UPDATE(2), 
	
	//删除
	DELETE(3);
	
	//数字代码
	private Integer code;
	
	//构造函数
	private EntityBuildType(Integer code){
		this.code = code;
	}
	
	//枚举转换成代码字符串
	@Override
	public String toString(){
		return code.toString();
	}
	
	//枚举转换成数字代码
	public int numeric(){
		return this.code.intValue();
	}
	
}
