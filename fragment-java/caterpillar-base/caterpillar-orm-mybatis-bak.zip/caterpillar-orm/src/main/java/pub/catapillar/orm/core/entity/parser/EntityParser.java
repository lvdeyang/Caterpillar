package pub.catapillar.orm.core.entity.parser;

import java.util.Set;

import pub.catapillar.orm.core.entity.metadata.EntityMetadataManager;

/**
 * entity解析器
 * lvdeyang 2017年6月14日
 */
public interface EntityParser {
	
	public void parse(Set<Class> entitySet);
	
}
