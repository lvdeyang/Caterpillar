package pub.catapillar.orm.core.driver.loader;

import java.util.Collection;
import java.util.Set;

/**
 * entity 加载器
 * lvdeyang 2017年6月15日
 */
public interface EntityLoader {

	public Set<Class> loadEntity(Collection<String> pathArr) throws Exception ;
	
}
