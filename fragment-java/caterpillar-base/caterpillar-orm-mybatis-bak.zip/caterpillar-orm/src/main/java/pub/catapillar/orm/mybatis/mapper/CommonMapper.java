package pub.catapillar.orm.mybatis.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import pub.catapillar.orm.mybatis.entity.CommonEntity;
import pub.catapillar.orm.mybatis.mapper.provider.CommonMapperProvider;

/**
 * mybatis基础dao接口
 * lvdeyang 2017年6月16日
 */
public interface CommonMapper<T extends CommonEntity> {

	//主键查询
	@SelectProvider(type=CommonMapperProvider.class, method="getById")
	public T get(@Param("id") Long id, @Param("entity") Class<T> c);
	
	//uuid查询
	//@SelectProvider(type=CommonDaoProvider.class, method="getByUuid")
	//public T get(@Param("uuid") String uuid, @Param("entity") Class<T> c);
	
	public T save();
	
	public void update();
	
	public void delete();
	
}
