package pub.catapillar.orm.core.entity.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import pub.catapillar.orm.core.entity.annotation.enumeration.FieldType;
import pub.catapillar.orm.core.entity.filed.EnumFiledType;

/**
 * 列映射
 * lvdeyang 2017年6月14日
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {

	//映射字段名
	public String name() default "";
	
	//字段类型
	public FieldType type() default FieldType.VARCHAR;
	
	//字段长度
	public long length() default 32l;
	
	//无符号
	public boolean unsigned() default false;
	
	//自增
	public boolean autoIncreace() default false;
	
	//枚举类型
	public Class<EnumFiledType> enumType() default EnumFiledType.class;
	
	//能否为空
	public boolean nullable() default true; 
	
}
