package pub.catapillar.orm.core.driver.dialect;

import pub.catapillar.orm.core.entity.filed.DataType;

/**
 * 数据库方言
 * lvdeyang 2017年6月14日
 */
public interface DatabaseDialect {

	/************************
	 *        数据类型
	 ************************/
	
	//获取本方言的数据类型
	public DataType getDialectDataType();
	
	//不可为空
	public String NOTNULL();
	
	//唯一约束
	public String UNIQUE();
	
	//无符号
	public String UNSIGNED();
	
	/************************
	 *         sql
	 ************************/
	
	
	
	/************************
	 *        元数据
	 ************************/
	
	//获取所有的表
	
	//获取所有的
	
	
	
}
