package pub.catapillar.orm.core.entity.metadata;

import java.util.Set;

/**
 * 实体元数据信息
 * lvdeyang 2017年6月14日
 */
public class EntityMatadata {

	//表名
	private String table;
	
	//主键
	private FieldMetadata key;
	
	//字段列表
	private Set<FieldMetadata> fieldSet;
	
	//建表语句
	
	//删表语句
	
	//加字段语句
	
	//外键
	
	
	
	
}
