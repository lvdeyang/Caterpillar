package pub.catapillar.orm.core.entity.filed;

/**
 * 字段映射枚举类型
 * lvdeyang 2017年6月14日
 */
public interface EnumFiledType {

}
