package pub.catapillar.orm.core.entity.annotation.enumeration;

import pub.catapillar.orm.core.driver.EntityAutoBuildingDriver;
import pub.catapillar.orm.core.entity.filed.DataTypeMetaData;

/**
 * 字段类型枚举
 * lvdeyang 2017年6月14日
 */
public enum FieldType {

	CHAR(EntityAutoBuildingDriver.getDialect().getDialectDataType().CHAR()),
	
	VARCHAR(EntityAutoBuildingDriver.getDialect().getDialectDataType().VARCHAR()),
	
	INT(EntityAutoBuildingDriver.getDialect().getDialectDataType().INT()),
	
	BIGINT(EntityAutoBuildingDriver.getDialect().getDialectDataType().BIGINT()),
	
	FLOAT(EntityAutoBuildingDriver.getDialect().getDialectDataType().FLOAT()),
	
	DOUBLE(EntityAutoBuildingDriver.getDialect().getDialectDataType().DOUBLE()),
	
	BLOB(EntityAutoBuildingDriver.getDialect().getDialectDataType().BLOB()),
	
	LONGBLOB(EntityAutoBuildingDriver.getDialect().getDialectDataType().LONGBLOB()),
	
	TEXT(EntityAutoBuildingDriver.getDialect().getDialectDataType().TEXT()),
	
	LONGTEXT(EntityAutoBuildingDriver.getDialect().getDialectDataType().LONGTEXT()),
	
	ENUM(EntityAutoBuildingDriver.getDialect().getDialectDataType().ENUM()),
	
	DATE(EntityAutoBuildingDriver.getDialect().getDialectDataType().DATE()),
	
	DATETIME(EntityAutoBuildingDriver.getDialect().getDialectDataType().DATETIME()),
	
	TIMESTAMP(EntityAutoBuildingDriver.getDialect().getDialectDataType().TIMESTAMP()),
	
	TIME(EntityAutoBuildingDriver.getDialect().getDialectDataType().TIME()),
	
	YEAR(EntityAutoBuildingDriver.getDialect().getDialectDataType().YEAR());
	
	private DataTypeMetaData metaData;
	
	private FieldType(DataTypeMetaData metaData){
		this.metaData = metaData;
	}
	
	public String toString(){
		return this.metaData.toString();
	}
	
}
