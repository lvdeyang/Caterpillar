package pub.catapillar.orm.mybatis.mapper.provider;

import java.util.Map;

public class CommonMapperProvider {

	//主键查询
	public String getById(Map<String, Object> param) {
		
		//Object entity = param.get("entity");
		
		return "select id, username from t_app_user where id=1";
	}
	
	//uuid查询
	public String getByUuid(Map<String, Object> param){
		
		String uuid = (String)param.get("uuid");
		
		return "select * from t_app_user where uuid='"+uuid+"'";
		
	}

	public String save() {
		// TODO Auto-generated method stub
		return null;
	}

	public String update() {
		// TODO Auto-generated method stub
		return null;
		
	}

	public String delete() {
		// TODO Auto-generated method stub
		return null;
	}

}
