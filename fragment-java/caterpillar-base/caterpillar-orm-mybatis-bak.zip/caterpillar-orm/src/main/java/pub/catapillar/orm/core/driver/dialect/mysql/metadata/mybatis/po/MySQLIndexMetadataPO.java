package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

/**
 * MySQL索引元数据
 * lvdeyang 2017年6月16日
 */
public class MySQLIndexMetadataPO {

	//索引名称
	private String INDEX_NAME;
	
	//索引包含的列名称
	private String COLUMN_NAME;
	
	//字段在索引中的排序
	private int SEQ_IN_INDEX;

	public String getINDEX_NAME() {
		return INDEX_NAME;
	}

	public MySQLIndexMetadataPO setINDEX_NAME(String iNDEX_NAME) {
		INDEX_NAME = iNDEX_NAME;
		return this;
	}

	public String getCOLUMN_NAME() {
		return COLUMN_NAME;
	}

	public MySQLIndexMetadataPO setCOLUMN_NAME(String cOLUMN_NAME) {
		COLUMN_NAME = cOLUMN_NAME;
		return this;
	}

	public int getSEQ_IN_INDEX() {
		return SEQ_IN_INDEX;
	}

	public MySQLIndexMetadataPO setSEQ_IN_INDEX(int sEQ_IN_INDEX) {
		SEQ_IN_INDEX = sEQ_IN_INDEX;
		return this;
	}
	
}
