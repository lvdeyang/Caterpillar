package pub.catapillar.orm.core.entity.metadata;

/**
 * 字段元数据
 * lvdeyang 2017年6月15日
 */
public class FieldMetadata {

}
