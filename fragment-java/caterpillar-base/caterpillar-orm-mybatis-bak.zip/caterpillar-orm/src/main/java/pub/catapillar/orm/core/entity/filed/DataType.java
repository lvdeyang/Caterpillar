package pub.catapillar.orm.core.entity.filed;

/**
 * 数据类型
 * lvdeyang 2017年6月14日
 */
public interface DataType {
	
	/*******************
	 *      文本类型
	 *******************/
	
	//CHAR max 255--字符
	public DataTypeMetaData CHAR();
	
	//VARCHAR max 255--字符
	public DataTypeMetaData VARCHAR();
	
	//TINYTEXT max 255--字符
	public DataTypeMetaData TINYTEXT();
	
	//TEXT max  65535--字符
	public DataTypeMetaData TEXT();
	
	//BLOB max 65,535--字节
	public DataTypeMetaData BLOB();
	
	//MEDIUMTEXT max 16,777,215--字符
	public DataTypeMetaData MEDIUMTEXT();
	
	//MEDIUMBLOB max 16,777,215--字节
	public DataTypeMetaData MEDIUMBLOB();
	
	//LONGTEXT max  4,294,967,295--字符
	public DataTypeMetaData LONGTEXT();
	
	//LONGBLOB max  4,294,967,295--字节
	public DataTypeMetaData LONGBLOB();
	
	//ENUM 实现DataType， 提供带参数的构造方法，重写toString方法
	public DataTypeMetaData ENUM();
	
	/*******************
	 *      数字类型
	 *******************/
	
	//单字节  -128 到 127 常规。0 到 255 无符号*
	public  DataTypeMetaData TINYINT();
	
	//双字节  -32768 到 32767 常规。0 到 65535 无符号*
	public DataTypeMetaData SMALLINT();
	
	//三字节 -8388608 到 8388607 普通。0 to 16777215 无符号*
	public DataTypeMetaData MEDIUMINT();
	
	//四字节 -2147483648 到 2147483647 常规。0 到 4294967295 无符号*
	public DataTypeMetaData INT();
	
	//八字节 -9223372036854775808 到 9223372036854775807 常规。0 到 18446744073709551615 无符号*
	public DataTypeMetaData BIGINT();
	
	//四字节
	public DataTypeMetaData FLOAT();
	
	//八字节
	public DataTypeMetaData DOUBLE();
	
	//八字节
	public DataTypeMetaData DECIMAL();
	
	/*******************
	 *      日期类型
	 *******************/
	
	//日期
	public DataTypeMetaData DATE();
	
	//日期时间
	public DataTypeMetaData DATETIME();
	
	//时间戳
	public DataTypeMetaData TIMESTAMP();
	
	//时间
	public DataTypeMetaData TIME();
	
	//年
	public DataTypeMetaData YEAR();
	
	
}
