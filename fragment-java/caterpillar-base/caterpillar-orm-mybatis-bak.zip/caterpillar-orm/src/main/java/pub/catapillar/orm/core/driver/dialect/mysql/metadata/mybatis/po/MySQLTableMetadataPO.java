package pub.catapillar.orm.core.driver.dialect.mysql.metadata.mybatis.po;

/**
 * MySQL表元数据信息
 * lvdeyang 2017年6月16日
 */
public class MySQLTableMetadataPO {

	//表名称
	private String TABLE_NAME;

	public String getTABLE_NAME() {
		return TABLE_NAME;
	}

	public MySQLTableMetadataPO setTABLE_NAME(String tABLE_NAME) {
		TABLE_NAME = tABLE_NAME;
		return this;
	}
	
}
